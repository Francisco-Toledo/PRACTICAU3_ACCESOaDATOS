package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Main {
    public static void main(String[] args) {
        //Creamos una configución de Hibernate
        Configuration configuration = new Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(User.class).addAnnotatedClass(Ticket.class);

        //Creamos la sesionFactory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Abrimos la sesion fatory


        Session session = null;
        try {
            session = sessionFactory.openSession();
            session.beginTransaction();

            //Creamos USUARIO
            User user = new User("Michael Laudrup");

            //CrEaMOS tickets para el usuario
            Ticket ticket1 = new Ticket(user, "Roller coaster", 5.00);
            Ticket ticket2 = new Ticket(user, "Bumper cars", 2.00);
            Ticket ticket3 = new Ticket(user, "Wheel of fortune", 1.00);

            //Gyardamos el Usuario y los ticketssss
            session.save(user);
            session.save(ticket1);
            session.save(ticket2);
            session.save(ticket3);

            // Commit de la transacción
            session.getTransaction().commit();

            System.out.println("Usuario y tickets guardados correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if   (sessionFactory != null && !sessionFactory.isClosed()) {
                sessionFactory.close();
            }
            }
        }
    }
